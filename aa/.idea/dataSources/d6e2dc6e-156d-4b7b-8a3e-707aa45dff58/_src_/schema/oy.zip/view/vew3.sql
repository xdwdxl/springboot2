CREATE VIEW vew3 AS
  SELECT
    max(`oy`.`score`.`成绩`) AS `MAX(成绩)`,
    min(`oy`.`score`.`成绩`) AS `MIN(成绩)`,
    avg(`oy`.`score`.`成绩`) AS `AVG(成绩)`
  FROM `oy`.`score`;
