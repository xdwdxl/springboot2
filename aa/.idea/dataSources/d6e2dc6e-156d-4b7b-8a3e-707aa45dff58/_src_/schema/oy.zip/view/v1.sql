CREATE VIEW v1 AS
  SELECT
    `oy`.`student`.`学号`     AS `学号`,
    `oy`.`student`.`学生姓名`   AS `学生姓名`,
    `oy`.`student`.`学生性别`   AS `学生性别`,
    `oy`.`student`.`学生出生年月` AS `学生出生年月`,
    `oy`.`student`.`学生所在班级` AS `学生所在班级`
  FROM `oy`.`student`
  WHERE (`oy`.`student`.`学生性别` = '女');
